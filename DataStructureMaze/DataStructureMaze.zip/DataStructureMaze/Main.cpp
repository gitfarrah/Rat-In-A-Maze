//#include <iostream>
//#include "Maze.h"
//using namespace std;
//#define N 10
//int main()
//{
//	int start[] = { 0, 0 };
//	int end[] = { N - 1, N - 1 };
//	string file = "C:\\Users\\farah\\source\\repos\\DataStructureMaze\\DataStructureMaze\\maze.txt";
//	Maze maze(start, end);
//	maze.read(file);
//	maze.findPath();
//	//maze.displaypath(N-1,N-1);
//
//}
//
